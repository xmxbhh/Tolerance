import  threading
import  socket
routers=[] #用于保存探测结果
lock = threading.Lock() #构造一把锁
def  main():
    local_ip = socket.gethostbyname_ex(socket.gethostname())
    all_threads=[]
    for ip in local_ip[2]:
              for i in range(1,255):
                    array = ip.split(".") #把IP以点号做分割
                    array[3]= str(i)
                    new_ip ='.'.join(array)  #在把列表的内容转换成IP
                    t = threading.Thread(target=check_ip,args=(new_ip,)) #构造线程池
                    t.start() #开启线程
                    all_threads.append(t)
              for t in all_threads:
                    t.join() #保持队列
def check_ip(new_ip):
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM) #创建套接字
    s.settimeout(1)
    PORT = 3306
    result = s.connect_ex((new_ip,PORT))
    if result ==0:
         lock.acquire() # 获取锁
         print(new_ip.ljust(15),'port %s is open' %PORT)
         lock.release() # 锁释放
print('search for router,please wait......')
if __name__ == '__main__':
    main()
