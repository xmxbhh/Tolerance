import importlib
import sys,os,re
from libs.nenu import * #菜单导入
requests.packages.urllib3.disable_warnings() # 禁用安全警告

if __name__ == '__main__':
######################################################################
    # 需要python3 版本
    if sys.version_info < (3, 0):
        sys.stdout.write("Error, Tolerance 需要 Python 3.x\n")
        sys.exit(1)
######################################################################
    #获取返回的参数和值
    if len(sys.argv)==2 and sys.argv[1]=="-r":
        Reload_POC()
        sys.exit(1)
    if not os.path.isfile(DB_NAME):
        print(color.blue(logo))
        print(color.red("[E]Error:数据库文件不存在，请执行-r重新加载数据文件！"))
        sys.exit(1)
######################################################################
    #运行主体命令
    Command_dict=getparameter()

    #疑似询关键词的漏洞主体
    Judgement_parameter(Command_dict)







